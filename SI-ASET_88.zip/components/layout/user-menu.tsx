"use client";

import { useState, useTransition } from "react";
import { LogOut } from "lucide-react";
import { Modal } from "@/components/ui/modal";
import { logout } from "@/lib/auth/actions";

const roleLabel: Record<string, string> = {
  admin: "Admin",
  guru: "Guru",
  kepsek: "Kepala Sekolah",
};

function inisial(nama: string) {
  return nama
    .trim()
    .split(/\s+/)
    .slice(0, 2)
    .map((kata) => kata[0]?.toUpperCase())
    .join("");
}

export function UserMenu({
  nama,
  role,
}: {
  nama: string;
  role: string;
}) {
  const [konfirmasiBuka, setKonfirmasiBuka] = useState(false);
  const [sedangKeluar, startTransition] = useTransition();

  function konfirmasiKeluar() {
    startTransition(async () => {
      await logout();
    });
  }

  return (
    <>
      <div className="hidden sm:block text-right leading-tight">
        <p className="text-[13px] text-ink font-medium">{nama}</p>
        <p className="text-[11px] text-ink-soft">
          {roleLabel[role] ?? role}
        </p>
      </div>

      <div className="w-8 h-8 rounded-full bg-pine text-paper text-xs font-medium flex items-center justify-center shrink-0">
        {inisial(nama)}
      </div>

      <button
        type="button"
        title="Keluar"
        onClick={() => setKonfirmasiBuka(true)}
        className="text-ink-soft hover:text-brick transition-colors"
      >
        <LogOut size={18} />
      </button>

      {konfirmasiBuka && (
        <Modal title="Keluar dari akun?" onClose={() => setKonfirmasiBuka(false)}>
          <div className="flex items-center gap-3 mb-5 p-3 bg-paper border border-line rounded-lg">
            <div className="w-9 h-9 rounded-full bg-pine text-paper text-xs font-medium flex items-center justify-center shrink-0">
              {inisial(nama)}
            </div>
            <div className="leading-tight min-w-0">
              <p className="text-[13px] text-ink font-medium truncate">{nama}</p>
              <p className="text-[12px] text-ink-soft">
                {roleLabel[role] ?? role}
              </p>
            </div>
          </div>
          <p className="text-[13px] text-ink-soft mb-5">
            Kamu perlu login lagi untuk mengakses SIMASET SD setelah keluar.
          </p>
          <div className="flex gap-3">
            <button
              onClick={konfirmasiKeluar}
              disabled={sedangKeluar}
              className="bg-brick text-paper text-sm font-medium px-4 py-2 rounded-lg hover:opacity-90 transition-opacity disabled:opacity-60"
            >
              {sedangKeluar ? "Keluar..." : "Ya, Keluar"}
            </button>
            <button
              onClick={() => setKonfirmasiBuka(false)}
              disabled={sedangKeluar}
              className="text-ink-soft text-sm px-4 py-2 rounded-lg hover:bg-paper transition-colors"
            >
              Batal
            </button>
          </div>
        </Modal>
      )}
    </>
  );
}
